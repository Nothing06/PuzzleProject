#include<stdio.h>

int main(void)
{
	printf("%d X %d = %d\n", 4, 5, 20);
	printf("%d / %d = %d\n", 24, 4, 6);
	printf("%d X %d = %d\n", 7, 9, 63);
	return 0;
}